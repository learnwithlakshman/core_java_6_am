package com.careerit.ems.domain;

public class Employee {
	private long empno;
	private String ename;
	private String email;
	private String mobile;
	private double salary;

	public Employee() {
		super();
	}

	public Employee(long empno, String ename, String email, String mobile, double salary) {
		super();
		this.empno = empno;
		this.ename = ename;
		this.email = email;
		this.mobile = mobile;
		this.salary = salary;
	}

	public long getEmpno() {
		return empno;
	}

	public void setEmpno(long empno) {
		this.empno = empno;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

}
