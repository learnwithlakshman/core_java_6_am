package com.careerit.ems.util;

import java.sql.*;

public class ConnectionUtil {

	private static ConnectionUtil obj = null;

	private ConnectionUtil() {
	}
	static {
		try {
			Class.forName("org.postgresql.Driver");
		}catch (Exception e) {
			System.out.println("While loading driver :"+e);
		}
	}

	public Connection getConnection() {
		String url = "jdbc:postgresql://localhost:5432/mydb";
		String username = "dbuser";
		String password = "dbuser";
		Connection con = null;
		try {
			con = DriverManager.getConnection(url, username, password);

		} catch (SQLException e) {
			System.out.println("While connecting with db :" + e);
		}
		return con;
	}

	public void close(ResultSet rs, Statement st, Connection con) {
		try {
			if (st != null) {
				st.close();
			}
			if (con != null) {
				con.close();
			}
			if (rs != null) {
				rs.close();
			}
		} catch (SQLException e) {
			System.out.println("While closing with database " + e);
		}
	}

	public void close(Statement st, Connection con) {
		try {
			if (st != null) {
				st.close();
			}
			if (con != null) {
				con.close();
			}
		} catch (SQLException e) {
			System.out.println("While closing with database " + e);
		}
	}

	public static ConnectionUtil getInstance() {
		synchronized (ConnectionUtil.class) {
			if (obj == null) {
				obj = new ConnectionUtil();
			}
		}
		return obj;
	}

}
