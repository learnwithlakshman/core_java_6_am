package com.careerit.ems.web;

import java.io.IOException;

import com.careerit.ems.dao.EmployeeDao;
import com.careerit.ems.dao.EmployeeDaoImpl;
import com.careerit.ems.domain.Employee;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/updateemp")
public class UpdateEmployeeServlet extends HttpServlet{
		
		private EmployeeDao empDao = new EmployeeDaoImpl();
		@Override
		protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
					long empno =Long.parseLong(req.getParameter("empno"));
					String ename = req.getParameter("ename");
					String email = req.getParameter("email");
					String mobile = req.getParameter("mobile");
					double salary = Double.parseDouble(req.getParameter("salary"));
					Employee emp = new Employee(empno,ename, email, mobile, salary);
					empDao.updateEmployee(emp);
				    resp.sendRedirect("emplist");
				    
		}
}
