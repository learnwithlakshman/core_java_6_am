package com.careerit.ems.dao;

import java.util.List;

import com.careerit.ems.domain.Employee;

public interface EmployeeDao {
	
		Employee insertEmployee(Employee emp);
		List<Employee> selectEmployees();
		Employee updateEmployee(Employee emp);
		boolean deleteEmployee(long empno);
		Employee selectEmployee(long empno);

}
