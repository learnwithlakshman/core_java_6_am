package com.careerit.ems.web;

import java.io.IOException;

import com.careerit.ems.dao.EmployeeDao;
import com.careerit.ems.dao.EmployeeDaoImpl;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	
		private EmployeeDao empDao = new EmployeeDaoImpl();
	
		@Override
		protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
			String username = req.getParameter("username");
			String password = req.getParameter("password");
			String userName = empDao.login(username, password);
			if(userName!=null) {
				resp.sendRedirect("emplist");
			}else {
				req.setAttribute("error", "Invalid credentials");
				RequestDispatcher rd = req.getRequestDispatcher("login.jsp");
				rd.forward(req, resp);
			}
				
		}
}
