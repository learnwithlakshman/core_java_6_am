package com.careerit.ems.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.careerit.ems.domain.Employee;
import com.careerit.ems.util.ConnectionUtil;

public class EmployeeDaoImpl implements EmployeeDao {
	
	private ConnectionUtil connUtil = ConnectionUtil.getInstance();
	private static final String EMP_LIST="select empno,ename,email,mobile,salary from employee";
	private static final String ADD_EMP = "insert into employee(ename,email,mobile,salary) values(?,?,?,?)";
	private static final String UPDATE_EMP= "update employee set ename=?,email=?,mobile=?,salary=? where empno=?";
	private static final String GET_EMP_BY_ID="select empno,ename,email,mobile,salary from employee where empno=?";
	private static final String DELETE_EMP_BY_ID="delete from employee where empno=?";
	
	private static final String LOGIN_USER="select user_name from app_user where user_name=? and password=?";
	
	
	@Override
	public Employee insertEmployee(Employee emp) {
		Connection con = null;
	    PreparedStatement st = null;
	    ResultSet rs = null;
	    try {
	      con = connUtil.getConnection();
	      st = con.prepareStatement(ADD_EMP,Statement.RETURN_GENERATED_KEYS);
	      st.setString(1,emp.getEname());
	      st.setString(2, emp.getEmail());
	      st.setString(3, emp.getMobile());
	      st.setDouble(4, emp.getSalary());
	      st.executeUpdate();
	      rs = st.getGeneratedKeys();
	      if (rs.next()) {
	        long empno = rs.getLong(1);
	        emp.setEmpno(empno);
	        System.out.println("Employee is added with id :"+empno);
	      }
	    } catch (SQLException e) {
	      
	      e.printStackTrace();
	    } finally {
	      connUtil.close(rs, st, con);
	    }
	    return emp;
	}

	@Override
	public List<Employee> selectEmployees() {
		Connection con = null;
		ResultSet rs = null;
		Statement st = null;
		List<Employee> list = new ArrayList<Employee>();
		try {
			con = connUtil.getConnection();
			st = con.createStatement();
			rs = st.executeQuery(EMP_LIST);
			while(rs.next()) {
				long empno = rs.getLong("empno");
				String ename = rs.getString("ename");
				String email = rs.getString("email");
				String mobile = rs.getString("mobile");
				double salary = rs.getDouble("salary");
				Employee employee = new Employee(empno, ename, email, mobile, salary);
				list.add(employee);
			}
		}catch (Exception e) {
			System.out.println("While getting employee details: "+e);
		}
		return list;
	}

	@Override
	public Employee updateEmployee(Employee emp) {
		Connection con = null;
	    PreparedStatement st = null;
	    try {
	      con = connUtil.getConnection();
	      st = con.prepareStatement(UPDATE_EMP);
	      st.setString(1,emp.getEname());
	      st.setString(2, emp.getEmail());
	      st.setString(3, emp.getMobile());
	      st.setDouble(4, emp.getSalary());
	      st.setLong(5, emp.getEmpno());
	      int res = st.executeUpdate();
	      if(res!=0) {
	    	  return emp;
	      }
	    } catch (SQLException e) {
	      
	      e.printStackTrace();
	    } finally {
	      connUtil.close( st, con);
	    }
	    return emp;
	}

	@Override
	public boolean deleteEmployee(long empno) {
		Connection con = null;
		PreparedStatement st = null;
		try {
			con = connUtil.getConnection();
			st = con.prepareStatement(DELETE_EMP_BY_ID);
			st.setLong(1, empno);
			 int res = st.executeUpdate();
			 if(res != 0) {
				 return true;
			 }
		}catch (Exception e) {
			System.out.println("While deleting employee details: "+e);
		}
		return false;
	}

	@Override
	public Employee selectEmployee(long empno) {
		Connection con = null;
		ResultSet rs = null;
		PreparedStatement st = null;
		try {
			con = connUtil.getConnection();
			st = con.prepareStatement(GET_EMP_BY_ID);
			st.setLong(1, empno);
			rs = st.executeQuery();
			if(rs.next()) {
				empno = rs.getLong("empno");
				String ename = rs.getString("ename");
				String email = rs.getString("email");
				String mobile = rs.getString("mobile");
				double salary = rs.getDouble("salary");
				Employee employee = new Employee(empno, ename, email, mobile, salary);
			    return employee;
			}
		}catch (Exception e) {
			System.out.println("While getting employee details: "+e);
		}
		return null;
	}
	
	public String login(String username,String password) {
		//
		
		return null;
	}

}
