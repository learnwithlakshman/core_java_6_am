package com.careerit.ems.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.careerit.ems.domain.Employee;
import com.careerit.ems.util.ConnectionUtil;

public class EmployeeDaoImpl implements EmployeeDao {
	
	private ConnectionUtil connUtil = ConnectionUtil.getInstance();
	private static final String EMP_LIST="select empno,ename,email,mobile,salary from employee";
	@Override
	public Employee insertEmployee(Employee emp) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Employee> selectEmployees() {
		Connection con = null;
		ResultSet rs = null;
		Statement st = null;
		List<Employee> list = new ArrayList<Employee>();
		try {
			con = connUtil.getConnection();
			st = con.createStatement();
			rs = st.executeQuery(EMP_LIST);
			while(rs.next()) {
				long empno = rs.getLong("empno");
				String ename = rs.getString("ename");
				String email = rs.getString("email");
				String mobile = rs.getString("mobile");
				double salary = rs.getDouble("salary");
				Employee employee = new Employee(empno, ename, email, mobile, salary);
				list.add(employee);
			}
		}catch (Exception e) {
			System.out.println("While getting employee details: "+e);
		}
		return list;
	}

	@Override
	public Employee updateEmployee(Employee emp) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean deleteEmployee(long empno) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Employee selectEmployee(long empno) {
		// TODO Auto-generated method stub
		return null;
	}

}
