package com.careerit.ems.dto;

public class RequestInfo {

		private String name;
		private String value;
		public RequestInfo(String name, String value) {
			super();
			this.name = name;
			this.value = value;
		}
		public RequestInfo() {
			super();
			// TODO Auto-generated constructor stub
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getValue() {
			return value;
		}
		public void setValue(String value) {
			this.value = value;
		}
		
		
}
