package com.careerit.ems.web;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

import com.careerit.ems.dto.RequestInfo;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/requestinfo")
public class RequestInfoServlet extends HttpServlet {

		@Override
		protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
			Enumeration<String> enumeration = req.getHeaderNames();
			List<RequestInfo> list = new ArrayList<RequestInfo>();
			while(enumeration.hasMoreElements()) {
					String name = enumeration.nextElement();
					String value = req.getHeader(name);
					RequestInfo obj = new RequestInfo(name, value);
					list.add(obj);
			}
			req.setAttribute("requestInfo", list);
			RequestDispatcher rd = req.getRequestDispatcher("requestinfo.jsp");
			rd.forward(req, resp);
		}
		
}
