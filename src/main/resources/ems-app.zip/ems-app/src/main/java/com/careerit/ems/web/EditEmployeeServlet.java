package com.careerit.ems.web;

import java.io.IOException;

import com.careerit.ems.dao.EmployeeDao;
import com.careerit.ems.dao.EmployeeDaoImpl;
import com.careerit.ems.domain.Employee;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/editemp")
public class EditEmployeeServlet extends HttpServlet {
	
		private EmployeeDao empDao = new EmployeeDaoImpl();
		@Override
		protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
				  long empno = Long.parseLong(req.getParameter("empno"));
				  System.out.println("Employee number :"+empno);
				  Employee employee = empDao.selectEmployee(empno);
				  req.setAttribute("emp", employee);
				  RequestDispatcher rd = req.getRequestDispatcher("editemp.jsp");
				  rd.forward(req, resp);
		}

}
